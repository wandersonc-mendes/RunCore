from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
)

from models.athlete import Athlete


class AthletesTable(QTableWidget):

    enterPressed = Signal()

    def __init__(self):
        super().__init__()

        self.setColumnCount(3)

        self.setHorizontalHeaderLabels(
            [
                "Nome",
                "Objetivo",
                "Status",
            ]
        )

        header = self.horizontalHeader()

        header.setSectionResizeMode(
            0,
            QHeaderView.Stretch,
        )

        header.setSectionResizeMode(
            1,
            QHeaderView.ResizeToContents,
        )

        header.setSectionResizeMode(
            2,
            QHeaderView.ResizeToContents,
        )

        self.setSelectionBehavior(
            QAbstractItemView.SelectRows
        )

        self.setSelectionMode(
            QAbstractItemView.SingleSelection
        )

        self.setEditTriggers(
            QAbstractItemView.NoEditTriggers
        )

        self.setSortingEnabled(True)

    def load(self, athletes: list[Athlete]):

        self.setSortingEnabled(False)

        self.setRowCount(len(athletes))

        for row, athlete in enumerate(athletes):

            item_name = QTableWidgetItem(athlete.name)
            item_goal = QTableWidgetItem(athlete.goal)
            item_status = QTableWidgetItem(
                "Ativo" if athlete.active else "Inativo"
            )

            item_name.setData(Qt.UserRole, athlete.id)

            self.setItem(row, 0, item_name)
            self.setItem(row, 1, item_goal)
            self.setItem(row, 2, item_status)

        self.setSortingEnabled(True)

    def selected_athlete_id(self):

        row = self.currentRow()

        if row < 0:
            return None

        item = self.item(row, 0)

        if item is None:
            return None

        return item.data(Qt.UserRole)

    def keyPressEvent(self, event: QKeyEvent):

        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.enterPressed.emit()
            return

        super().keyPressEvent(event)